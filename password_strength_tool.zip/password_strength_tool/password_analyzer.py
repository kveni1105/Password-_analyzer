"""
password_analyzer.py

Performs password strength analysis using zxcvbn and returns detailed feedback,
including score, crack time, and suggestions.
"""

try:
    from zxcvbn import zxcvbn
except ImportError:
    raise ImportError("zxcvbn is not installed. Run: pip install zxcvbn")

def analyze_password(password: str) -> dict:
    """
    Analyze the given password and return its strength score, crack time estimates,
    and feedback suggestions.

    Parameters:
        password (str): The password to analyze.

    Returns:
        dict: A dictionary with keys:
              - score (int): Strength score from 0 (weak) to 4 (strong)
              - crack_times_display (dict): Human-readable crack time estimates
              - feedback (dict): Warnings and suggestions for improvement
              - guesses (int): Estimated number of guesses needed
              - password_length (int): Length of the password
    """
    result = zxcvbn(password)

    return {
        "score": result.get("score", 0),
        "crack_times_display": result.get("crack_times_display", {}),
        "feedback": result.get("feedback", {}),
        "guesses": result.get("guesses", 0),
        "password_length": len(password)
    }

# Optional test
if __name__ == "__main__":
    test_pwd = input("Enter password to test: ")
    analysis = analyze_password(test_pwd)
    for key, val in analysis.items():
        print(f"{key}: {val}")
