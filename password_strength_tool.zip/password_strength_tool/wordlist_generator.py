import itertools

def leetspeak(word):
    """Convert a word to leetspeak."""
    leet_dict = {'a': '@', 'e': '3', 'i': '1', 'o': '0', 's': '$', 't': '7'}
    return ''.join(leet_dict.get(c.lower(), c) for c in word)

def generate_wordlist(user_info):
    """
    Generate a custom wordlist based on user info.
    :param user_info: Dictionary with keys: name, dob, pet
    :return: List of password variants
    """
    base_words = []

    for key in ['name', 'dob', 'pet']:
        value = user_info.get(key, '')
        base_words.append(value)
        base_words.append(value.lower())
        base_words.append(value.upper())
        base_words.append(value[::-1])            # Reversed
        base_words.append(leetspeak(value))       # Leetspeak

    years = ['2024', '2025', '123', '321']

    wordlist = set()

    for word in base_words:
        wordlist.add(word)
        for year in years:
            wordlist.add(word + year)
            wordlist.add(year + word)

    # Combine two-word combos
    for combo in itertools.permutations(base_words, 2):
        wordlist.add(''.join(combo))

    return list(wordlist)
