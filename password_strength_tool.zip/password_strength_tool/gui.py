import ttkbootstrap as tb
from ttkbootstrap.constants import *
from tkinter import messagebox
from password_analyzer import analyze_password
from wordlist_generator import generate_wordlist
import os

# ----------------------------- Analyze Function ----------------------------- #
def analyze():
    password = password_entry.get()
    name = name_entry.get()
    dob = dob_entry.get()
    pet = pet_entry.get()

    if not password:
        messagebox.showerror("Input Error", "Please enter a password to analyze.")
        return

    result = analyze_password(password)
    score_label.config(
        text=f"🧠 Score: {result['score']}/4",
        bootstyle="info" if result['score'] >= 3 else "danger"
    )

    crack_time = result['crack_times_display'].get("offline_slow_hashing_1e4_per_second", "Unknown")
    crack_time_label.config(text=f"🕒 Crack Time: {crack_time}")

    suggestions = " ".join(result['feedback'].get('suggestions', []))
    feedback_label.config(text=f"💡 Suggestions: {suggestions}" if suggestions else "No suggestions needed.")

    os.makedirs("sample_outputs", exist_ok=True)
    with open("sample_outputs/analysis_result.txt", "w") as f:
        f.write(str(result))

    if name or dob or pet:
        generate_wordlist(name, dob, pet)
        messagebox.showinfo("Success ✅", "Analysis complete and wordlist generated!")
    else:
        messagebox.showinfo("Success ✅", "Analysis complete.")

# ----------------------------- Clear Fields ----------------------------- #
def clear_fields():
    for entry in [password_entry, name_entry, dob_entry, pet_entry]:
        entry.delete(0, 'end')
    score_label.config(text="")
    crack_time_label.config(text="")
    feedback_label.config(text="")

# ----------------------------- App Window Setup ----------------------------- #
app = tb.Window(themename="morph")  # Try: minty, flatly, darkly, morph, solar
app.title("🔐 Password Strength Analyzer")
app.geometry("640x540")
app.resizable(False, False)

# ----------------------------- Main Frame ----------------------------- #
main_frame = tb.Frame(app, padding=30)
main_frame.pack(fill='both', expand=True)

# ----------------------------- Header ----------------------------- #
header = tb.Label(main_frame, text="🔐 Password Strength Analyzer",
                  font=("Helvetica", 22, "bold"), bootstyle="primary inverse")
header.pack(pady=(10, 20))

# ----------------------------- Form Frame ----------------------------- #
form = tb.Frame(main_frame, padding=10)
form.pack()

# ----------------------------- Input Fields ----------------------------- #
tb.Label(form, text="🔑 Password:", font=("Segoe UI", 11), bootstyle="secondary").grid(row=0, column=0, sticky="w", pady=8)
password_entry = tb.Entry(form, width=40, show="*")
password_entry.grid(row=0, column=1, pady=8, padx=5)

tb.Label(form, text="👤 Name:", font=("Segoe UI", 11), bootstyle="secondary").grid(row=1, column=0, sticky="w", pady=8)
name_entry = tb.Entry(form, width=40)
name_entry.grid(row=1, column=1, pady=8, padx=5)

tb.Label(form, text="🎂 Date of Birth:", font=("Segoe UI", 11), bootstyle="secondary").grid(row=2, column=0, sticky="w", pady=8)
dob_entry = tb.Entry(form, width=40)
dob_entry.grid(row=2, column=1, pady=8, padx=5)

tb.Label(form, text="🐶 Pet Name:", font=("Segoe UI", 11), bootstyle="secondary").grid(row=3, column=0, sticky="w", pady=8)
pet_entry = tb.Entry(form, width=40)
pet_entry.grid(row=3, column=1, pady=8, padx=5)

# ----------------------------- Buttons ----------------------------- #
btn_frame = tb.Frame(main_frame)
btn_frame.pack(pady=20)

tb.Button(btn_frame, text="🔍 Analyze", command=analyze, bootstyle="success-outline").pack(side="left", padx=10)
tb.Button(btn_frame, text="🧹 Clear", command=clear_fields, bootstyle="danger-outline").pack(side="left", padx=10)

# ----------------------------- Result Labels ----------------------------- #
score_label = tb.Label(main_frame, text="", font=("Segoe UI", 12, "bold"), bootstyle="info")
score_label.pack(pady=5)

crack_time_label = tb.Label(main_frame, text="", font=("Segoe UI", 12), bootstyle="warning")
crack_time_label.pack(pady=5)

feedback_label = tb.Label(main_frame, text="", font=("Segoe UI", 11), wraplength=560, justify="left", bootstyle="light")
feedback_label.pack(pady=5)

# ----------------------------- Run GUI ----------------------------- #
app.mainloop()
