# 🔐 Password Strength Analyzer with Custom Wordlist Generator

## 📌 Objective
A Python-based tool that analyzes the strength of user passwords using `zxcvbn` and generates a **custom wordlist** for use in password cracking tools (like John the Ripper or Hydra).

---

## 🧰 Tools & Libraries Used
- Python 🐍
- `argparse` – for command-line arguments
- `nltk` – for natural language variations
- `zxcvbn` – to measure password strength
- `tkinter` (Optional GUI)
- `os`, `itertools`, `datetime` – standard utilities

---

## 🚀 Features
- Analyze passwords and return a strength **score and crack time**.
- Accepts personal info like:
  - Name
  - Date of Birth
  - Pet name
- Generates wordlist using patterns:
  - Leetspeak (e.g., `a -> @`, `e -> 3`)
  - Common suffixes (`123`, `@`, etc.)
  - Year combinations (`1999`, `2000`)
- Exports:
  - `sample_outputs/custom_wordlist.txt`
  - `sample_outputs/analysis_result.txt`

---

## 🛠 How to Run

### ✅ Step 1: Clone or Download the Project
```bash
git clone https://github.com/your-username/password_strength_tool.git
cd password_strength_tool
