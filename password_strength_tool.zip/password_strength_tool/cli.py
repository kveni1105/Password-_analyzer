import argparse
from password_analyzer import analyze_password
from wordlist_generator import generate_wordlist

def main():
    parser = argparse.ArgumentParser(description="🔐 Password Strength Analyzer & Custom Wordlist Generator")
    
    parser.add_argument("-p", "--password", help="Password to analyze", required=True)
    parser.add_argument("-n", "--name", help="User's name", required=False, default="")
    parser.add_argument("-d", "--dob", help="Date of Birth", required=False, default="")
    parser.add_argument("-t", "--pet", help="Pet's name", required=False, default="")
    
    args = parser.parse_args()

    # Analyze password
    result = analyze_password(args.password)

    print("\n🔍 Password Analysis Result:")
    print(f"Score      : {result['score']} / 4")
    print(f"Crack Time : {result['crack_time']}")
    if result['feedback']:
        print("Suggestions:")
        for suggestion in result['feedback']:
            print(f" - {suggestion}")
    
    # Generate wordlist
    user_info = {
        "name": args.name,
        "dob": args.dob,
        "pet": args.pet
    }

    wordlist = generate_wordlist(user_info)
    wordlist_file = "sample_outputs/custom_wordlist.txt"
    analysis_file = "sample_outputs/analysis_result.txt"

    # Save wordlist
    with open(wordlist_file, "w") as f:
        for word in wordlist:
            f.write(word + "\n")

    # Save analysis
    with open(analysis_file, "w") as f:
        f.write("Password Analysis:\n")
        f.write(f"Score: {result['score']} / 4\n")
        f.write(f"Crack Time: {result['crack_time']}\n")
        f.write("Suggestions:\n")
        for tip in result['feedback']:
            f.write(f" - {tip}\n")

    print(f"\n📄 Wordlist saved to: {wordlist_file}")
    print(f"📄 Analysis report saved to: {analysis_file}")

if __name__ == "__main__":
    main()
